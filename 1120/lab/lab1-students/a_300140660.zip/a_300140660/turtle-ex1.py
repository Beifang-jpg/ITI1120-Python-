import turtle
s=turtle.Screen()
t=turtle.Turtle()

# Place your code after this line

t.speed(5)


t.penup()
t.goto(0, -8.5)
t.setheading(0)
t.pendown()
t.circle(8.5)

t.penup()
t.goto(0, -33.5)
t.setheading(0)
t.pendown()
t.circle(33.5)

t.penup()
t.goto(0, -57.5)
t.setheading(0)
t.pendown()
t.circle(57.5)

t.penup()
t.goto(0, -82.5)
t.setheading(0)
t.pendown()
t.circle(82.5)

# Drawing circle end
# Lines later

t.penup()
t.goto(0, 0)
t.setheading(0)
t.pendown()
t.forward(200)


t.penup()
t.goto(0, 0)
t.setheading(45)
t.pendown()
t.forward(200)

t.penup()
t.goto(0, 0)
t.setheading(90)
t.pendown()
t.forward(200)

t.penup()
t.goto(0, 0)
t.setheading(135)
t.pendown()
t.forward(200)

t.penup()
t.goto(0, 0)
t.setheading(180)
t.pendown()
t.forward(225)

t.penup()
t.goto(0, 0)
t.setheading(225)
t.pendown()
t.forward(200)

t.penup()
t.goto(0, 0)
t.setheading(270)
t.pendown()
t.forward(200)

t.penup()
t.goto(0, 0)
t.setheading(315)
t.pendown()
t.forward(200)